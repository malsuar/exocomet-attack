from setuptools import setup
setup(
    name="exocometary",
    version="0.0.1",
    description="Paquete que calcula la propiedad de colision entre exocometas y exoplanetas",
    author="Mario Sucerquia",
    author_email="mario.sucerquia@uv.cl",
    url="https://github.com/malsuar/exocometary.",
    #packages=['properties','evolution','figures'],
    scripts=[]
)